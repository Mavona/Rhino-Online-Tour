import { LightningElement, track, wire } from 'lwc';
// import buildEnquiryFormBody from '@salesforce/apex/EnquiryCallOut.buildEnquiryFormBody';
import holidayTypes from '@salesforce/apex/EnquiryCallout.holidayTypes';
import country from '@salesforce/apex/EnquiryCallout.country';
import enquiryTypes from '@salesforce/apex/EnquiryCallout.enquiryTypes';
import createEnquiry from '@salesforce/apex/Enquiry.createEnquiry';
import './contactForm.css';
export default class Contact_Form extends LightningElement {
    @track enquiryName;
    @track enquiryNumber;
    @track arrivalDate;
    @track comments;
    @track countryOptions = {};
    @track country;
    @track departure;
    @track email;
    @track holidayTyp = {};
    @track enquiryType;
    @track enquiryTyp = {};
    @track firstName;
    @track holidayType;
    @track lastName;
    @track numberofadults;
    @track numberofchildren;
    @track phone;
   

    constructor() {
        super();
        this.submit = this.submit.bind(this);
         
    }
    handlearrivaldate(event){
        this.arrivalDate = event.target.value;
    }
    handleenquiryname(event){
        this.enquiryName = event.target.value;
    }
    handleenquirynumber(event){
        this.enquiryNumber = event.target.value;
    }
    handlecomments(event){
        this.comments = event.target.value;
    }
    handlecountry(event){
        this.country = event.target.value;
    }
    handledeparture(event){
        this.departure = event.target.value;
    }
    handleemail(event){
        this.email = event.target.value;
    }
    handleenquiryType(event){
        this.enquiryType = event.target.value;
    }
    handlefirstName(event){
        this.firstName = event.target.value;
    }
    handleholidayType(event){
        this.holidayType = event.target.value;
    }
    handlelastName(event){
        this.lastName = event.target.value;
    }
    handlenumberofadults(event){
        this.numberofadults = event.target.value;
    }
    handlenumberofchildren(event){
        this.numberofchildren = event.target.value;
    }
    handlephone(event){
        this.phone = event.target.value;
    }
    
    
    @wire(holidayTypes)
    getHolidayList({error,data}){
        if (data){
            console.log(data);
            this.holidaytyp = data.map(option=>({label:option,value:option}));
        }
    }
    @wire(country)
    getCountryList({error,data}){
        if (data){
            this.countryOptions = data.map(option=>({label:option,value:option}));
        }
    }
     @wire(enquiryTypes)
    getenquiryList({error,data}){
        if (data){
            this.enquiryTyp = data.map(option=>({label:option,value:option}));
        }
    }
    // Function to collect data and send it
    submit() {
        createEnquiry(
            {arrivalDate:this.arrivalDate,
            comments:this.comments,
            country:this.country,
            departure:this.departure,
            email:this.email,
            enquiryType:this.enquiryType,
            firstName:this.firstName,
            holidayType:this.holidayType,
            lastName:this.lastName,
            numberofadults:this.numberofadults,
            numberofchildren:this.numberofchildren,
            phone:this.phone

        }).
        then(rasp => console.log(rasp)).
        catch(error => console.error(error));
    }
}